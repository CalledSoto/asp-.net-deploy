﻿namespace HPlusSports.Models
{
    public class ProductRating
    {
        public string SKU { get; set; }
        public double? Rating { get; set; }
        public int ReviewCount { get; set; }
    }
}