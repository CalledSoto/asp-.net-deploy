﻿function onInit() {
  $('table.tablesorter').tablesorter();

  var $content = $('#main');
  $content.on('click', '[data-partial]', function (evt) {

    var url = $(evt.target).attr('href');
    $content.load(url);

    evt.preventDefault();
    evt.stopPropagation();
  })
}

$(onInit)